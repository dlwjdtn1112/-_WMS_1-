create
    definer = sakila@localhost procedure dynamic_query2(IN t_name varchar(50), IN c_name varchar(50), IN customer_id int)
BEGIN
   set @t_name = t_name;
   set @c_name = c_name;
   set @customer_id = customer_id;
   set @sql = concat('SELECT',@c_name,' FROM ',@t_name,' WHERE cumstomer_id = ',@customer_id);

   SELECT @sql;
   PREPARE dynamic_query FROM @sql;
   EXECUTE  dynamic_query;
   DEALLOCATE  PREPARE dynamic_query;
END;

