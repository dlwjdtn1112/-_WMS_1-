create
    definer = sakila@localhost procedure sakilaCustomer()
BEGIN
    DECLARE customer_cnt INT;
    DECLARE add_number INT; -- 변수선언

    SET customer_cnt =0;
    SET  add_number  = 10;
    SET customer_cnt = (select  count(*) FROM customer);

    SELECT customer_cnt;


end;

