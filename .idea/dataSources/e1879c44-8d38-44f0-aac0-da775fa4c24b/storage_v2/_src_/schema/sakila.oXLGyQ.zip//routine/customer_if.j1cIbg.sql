create
    definer = sakila@localhost procedure customer_if(IN customer_id_input int)
BEGIN
        DECLARE store_id_i int;
        DECLARE s_id_one int;
        DECLARE s_id_two int;

        SET store_id_i = (select store_id from customer where customer_id_input);

        if store_id_i = 1 then set s_id_one = 1;
        ELSE SET s_id_two = 2;
        END IF;

        SELECT  store_id_i,s_id_one,s_id_two;

    end;

