create
    definer = sakila@localhost procedure customer_level_case(IN customer_id_input int)
BEGIN
    DECLARE customer_level VARCHAR(10);  -- 고객 등급 (문자열이므로 INT 대신 VARCHAR 사용)
    DECLARE amount_sum FLOAT;            -- 고객의 총 결제 금액 저장

    -- 고객의 총 결제 금액 조회
    SET amount_sum = (SELECT SUM(amount) FROM payment WHERE customer_id = customer_id_input);

    -- 고객 등급 결정 (CASE 사용)
    CASE
        WHEN amount_sum >= 150 THEN SET customer_level = 'vvip';
        WHEN amount_sum >= 125 THEN SET customer_level = 'vip';
        WHEN amount_sum >= 100 THEN SET customer_level = 'gold';
        WHEN amount_sum >= 80 THEN SET customer_level = 'silver';
        ELSE SET customer_level = 'bronze';
        END CASE;

    -- 결과 출력
    SELECT customer_id_input AS customer_id, amount_sum, customer_level;
END;

