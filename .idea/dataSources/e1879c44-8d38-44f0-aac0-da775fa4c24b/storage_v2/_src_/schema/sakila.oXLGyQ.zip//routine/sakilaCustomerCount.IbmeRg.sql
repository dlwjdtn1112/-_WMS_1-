create
    definer = sakila@localhost procedure sakilaCustomerCount()
BEGIN
    DECLARE customer_cnt int;
    DECLARE add_number int;

    set customer_cnt = 0;
    set add_number = 10;

    set customer_cnt = (select count(*) from customer);

    select customer_cnt;
end;

