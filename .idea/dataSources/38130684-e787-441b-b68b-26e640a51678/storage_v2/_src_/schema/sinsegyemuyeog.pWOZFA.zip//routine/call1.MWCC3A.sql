create
    definer = mypra5@localhost procedure call1(IN user_name varchar(50))
begin
    select * from 고객 where 담당자명 = user_name;
end;

