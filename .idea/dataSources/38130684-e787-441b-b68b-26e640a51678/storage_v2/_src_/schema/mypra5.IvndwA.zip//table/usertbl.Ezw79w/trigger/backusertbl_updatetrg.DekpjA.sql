create definer = mypra5@localhost trigger backUserTbl_UpdateTrg
    after update
    on usertbl
    for each row
BEGIN
    insert into  backup_usertbl values (OLD.userID,OLD.name,OLD.birthYear,OLD.addr,OLD.mobile1,OLD.mobile2,OLD.height,OLD.mDate,'수정',CURDATE(),CURRENT_USER());

end;

