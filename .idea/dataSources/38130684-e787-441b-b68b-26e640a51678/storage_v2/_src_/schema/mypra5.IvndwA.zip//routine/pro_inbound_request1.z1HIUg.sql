create
    definer = mypra5@localhost procedure pro_inbound_request1(IN u_product_id varchar(20), IN u_inbound_quantity int,
                                                              IN u_req_inbound_day varchar(20),
                                                              IN u_warehouse_id varchar(20))
BEGIN
    DECLARE last_insert_id INT;
    DECLARE new_inbound_id VARCHAR(20);

    -- ✅ inbound_id는 INSERT할 필요 없음 (AUTO_INCREMENT id가 자동 증가)
    INSERT INTO inbound (product_id, inbound_quantity, req_inbound_day, warehouse_id)
    VALUES (u_product_id, u_inbound_quantity, u_req_inbound_day, u_warehouse_id);

    -- ✅ 방금 삽입된 AUTO_INCREMENT 값 가져오기
    SET last_insert_id = LAST_INSERT_ID();

    -- ✅ 'in' + AUTO_INCREMENT된 ID 생성
    SET new_inbound_id = CONCAT('in', last_insert_id);

    -- ✅ 생성된 inbound_id 업데이트
    UPDATE inbound
    SET inbound_id = new_inbound_id
    WHERE id = last_insert_id;  -- ✅ 숫자형 ID 기반으로 업데이트

END;

