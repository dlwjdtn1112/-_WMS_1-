create
    definer = mypra5@localhost procedure GetUserInfoByName1(IN birthYear int, IN height int)
BEGIN
    SELECT * FROM usertbl WHERE birthYear >= 1970 and height > 178;
END;

