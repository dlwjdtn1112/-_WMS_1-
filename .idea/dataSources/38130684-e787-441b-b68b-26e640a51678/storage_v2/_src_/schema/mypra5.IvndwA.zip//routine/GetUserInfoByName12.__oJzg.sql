create
    definer = mypra5@localhost procedure GetUserInfoByName12(IN birthYear1 int, IN height1 int)
BEGIN
    SELECT * FROM usertbl WHERE birthYear >= birthYear1 and height > height1;
END;

