create
    definer = mypra5@localhost procedure whileProcsum2()
begin
  declare i int default 0;
  declare sum int default 0;
  
  while (i < 101) do
    set sum  = sum + i;
    set i  = i + 2;
    
  end while;
  select sum as result;


end;

