create
    definer = mypra5@localhost procedure pro_inventory_status()
begin
    select * from inventory;
end;

