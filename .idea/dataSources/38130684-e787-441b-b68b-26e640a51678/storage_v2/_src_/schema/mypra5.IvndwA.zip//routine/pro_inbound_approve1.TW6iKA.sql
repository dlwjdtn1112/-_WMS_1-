create
    definer = mypra5@localhost procedure pro_inbound_approve1(IN u_inbound_id int)
BEGIN
    DECLARE a INT;
    DECLARE v_product_id VARCHAR(20);
    DECLARE v_warehouse_id VARCHAR(20);

    -- 1. inbound_id에 해당하는 데이터를 조회하여 변수에 저장
    SELECT inbound_quantity, product_id, warehouse_id
    INTO a, v_product_id, v_warehouse_id
    FROM inbound
    WHERE inbound_id = u_inbound_id;

    -- 2. inbound 테이블의 status를 승인 상태로 변경
    UPDATE inbound
    SET status = '승인 수락'
    WHERE inbound_id = u_inbound_id;

    -- 3. inventory 테이블에 해당 상품이 있는지 확인
    IF EXISTS (SELECT 1 FROM inventory WHERE product_id = v_product_id AND warehouse_id = v_warehouse_id) THEN
        -- 존재하면 수량 업데이트
        UPDATE inventory
        SET quantity = quantity + a
        WHERE product_id = v_product_id AND warehouse_id = v_warehouse_id;
    ELSE
        -- 존재하지 않으면 새로운 상품을 추가
        INSERT INTO inventory (product_id, warehouse_id, quantity)
        VALUES (v_product_id, v_warehouse_id, a);
    END IF;

END;

