create
    definer = mypra5@localhost procedure realcall()
begin
    select * from realMadrid;
end;

