create
    definer = mypra5@localhost procedure nameTblProc(IN tblname varchar(20))
begin
      
       set @sqlQuery = concat ('select * from', tblname);
       prepare myQuery from @sqlQuery;
       execute myQuery;
       deallocate prepare myquery;

     
     end;

