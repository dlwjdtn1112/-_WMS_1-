create
    definer = mypra5@localhost procedure pro_outbound_request(IN u_product_id varchar(20), IN u_outbound_quantity int,
                                                              IN u_req_outbound_day varchar(20),
                                                              IN u_warehouse_id varchar(20))
BEGIN
    insert into outbound(outbound_id,product_id, outbound_quantity, req_outbound_day, warehouse_id)
    values (outbound_id,u_product_id,u_outbound_quantity,
            u_req_outbound_day,u_warehouse_id);

end;

