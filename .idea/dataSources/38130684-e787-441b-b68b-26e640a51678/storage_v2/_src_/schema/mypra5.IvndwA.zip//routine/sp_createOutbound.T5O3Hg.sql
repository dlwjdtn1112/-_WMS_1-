create
    definer = mypra5@localhost procedure sp_createOutbound(IN p_outbound_number varchar(30), IN p_prod_id varchar(10),
                                                           IN p_client_id varchar(30), IN p_quantity int,
                                                           IN p_ware_id varchar(10))
BEGIN
    DECLARE available_quantity INT;
SELECT quantity INTO available_quantity
FROM warehouse
WHERE prod_id = p_prod_id AND ware_id = p_ware_id;

IF available_quantity IS NULL OR available_quantity < p_quantity THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '창고에 출고할 상품이 없거나 수량이 부족합니다.';
ELSE
        INSERT INTO outbound (outbound_number, prod_id, client_id, quantity, status, req_outbound_day, ware_id)
        VALUES (p_outbound_number, p_prod_id, p_client_id, p_quantity, 0, CURDATE(), p_ware_id);

UPDATE warehouse
SET quantity = quantity - p_quantity, last_outbount_day = CURDATE()
WHERE prod_id = p_prod_id AND ware_id = p_ware_id;
END IF;
END;

