create
    definer = mypra5@localhost procedure pro_inbound_reject(IN u_inbound_id int)
BEGIN
    update inbound set status = '승인 거부' where inbound_id = u_inbound_id;

end;

