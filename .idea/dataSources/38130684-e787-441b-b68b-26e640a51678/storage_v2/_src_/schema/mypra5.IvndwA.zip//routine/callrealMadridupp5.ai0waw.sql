create
    definer = mypra5@localhost procedure callrealMadridupp5(IN user_id int)
begin
    select * from realMadrid where player_id > user_id;
end;

