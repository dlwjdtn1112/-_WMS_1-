create definer = mypra5@localhost view v_usertbl as
select `mypra5`.`usertbl`.`userID` AS `userID`,
       `mypra5`.`usertbl`.`name`   AS `name`,
       `mypra5`.`usertbl`.`addr`   AS `addr`
from `mypra5`.`usertbl`;

