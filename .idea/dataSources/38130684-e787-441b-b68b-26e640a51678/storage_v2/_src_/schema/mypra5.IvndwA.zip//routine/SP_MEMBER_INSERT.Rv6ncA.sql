create
    definer = mypra5@localhost procedure SP_MEMBER_INSERT(IN TName varchar(20), IN userid varchar(20),
                                                          IN pwd varchar(20), IN email varchar(50), IN hp varchar(20),
                                                          IN point int, OUT resultMsg varchar(20))
BEGIN
    -- 쿼리문 생성
    set @userid = userid;
    set @pwd  = pwd;
    set @email = email;
    set @point = point;
    set resultMsg = '회원 정보가 안잔하게 저장되었습니다.';

    set @strsql = concat('insert into',TName,'(m_userid, m_pwd, m_email, m_hp, m_registdate, m_poin)','values(?,?,?,?,now(),?);');

    prepare stmt from @strsql;
    execute stmt using @userid, @pwd, @email, @hp, @point;
    deallocate prepare stmt;
    commit;

END;

