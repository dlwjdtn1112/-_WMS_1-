create
    definer = mypra5@localhost procedure HelloWorld()
BEGIN
    SELECT 'Hello, World!';
END;

