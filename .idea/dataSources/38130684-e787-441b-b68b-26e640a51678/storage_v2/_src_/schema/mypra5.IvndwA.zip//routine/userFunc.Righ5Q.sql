create
    definer = mypra5@localhost function userFunc(value1 int, value2 int) returns int
begin
    return value1 + value2;

end;

