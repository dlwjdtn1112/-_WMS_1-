create
    definer = mypra5@localhost procedure sp_getWarehouseListByProduct(IN p_prod_id varchar(10))
BEGIN
SELECT w.ware_id, w.client_id, wa.ware_name, wa.ware_location, w.quantity
FROM warehouse w
         JOIN warehouse_area wa ON w.ware_id = wa.ware_id
WHERE w.prod_id = p_prod_id AND w.quantity > 0;
END;

