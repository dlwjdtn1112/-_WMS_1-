create definer = mypra5@localhost trigger usertbl_BeforeInsertTrg
    before insert
    on usertbl
    for each row
begin
    if new.birthYear < 1900 then
        set new.birthYear = 0;
    elseif new.birthYear > year(curdate()) then
        set new.birthYear = year(curdate());
    end if ;
end;

