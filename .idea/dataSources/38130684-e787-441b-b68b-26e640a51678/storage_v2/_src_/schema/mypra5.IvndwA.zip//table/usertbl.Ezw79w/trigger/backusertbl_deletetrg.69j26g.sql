create definer = mypra5@localhost trigger backUserTbl_DeleteTrg
    after delete
    on usertbl
    for each row
begin
    insert into backup_userTbl values (OLD.userID,OLD.name,
                                       OLD.birthYear,OLD.addr,OLD.mobile1,OLD.mobile2,OLD.height,OLD.mDate,
                                       '삭제',CURDATE(),CURRENT_USER());
end;

