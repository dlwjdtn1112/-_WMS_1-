create definer = mypra5@localhost trigger orderTrg
    after insert
    on ordertbl
    for each row
BEGIN
    UPDATE prodTbl SET account = account - NEW.orderamount
    WHERE prodName = NEW.prodName ;
END;

