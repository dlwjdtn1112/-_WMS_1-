create
    definer = mypra5@localhost procedure pro_warehouse_status()
begin
    select * from warehouse;
end;

