create
    definer = mypra5@localhost procedure GetAllEmployees(IN a varchar(50))
BEGIN
    SELECT * FROM employees where role = a;
END;

