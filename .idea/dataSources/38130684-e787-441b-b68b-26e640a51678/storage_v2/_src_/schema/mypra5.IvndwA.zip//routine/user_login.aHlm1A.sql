create
    definer = mypra5@localhost procedure user_login(IN a_userid int, IN a_userpassword varchar(255), OUT login_result int)
BEGIN
    DECLARE v_userpassword VARCHAR(255);

    -- 사용자 비밀번호 조회
    SELECT userpassword INTO v_userpassword
    FROM users
    WHERE userid = a_userid;

    -- 로그인 검증
    IF v_userpassword = a_userpassword THEN
        SET login_result = 0; -- 로그인 성공
    ELSE
        SET login_result = 1; -- 비밀번호 불일치
    END IF;

END;

