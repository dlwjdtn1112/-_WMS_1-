create
    definer = mypra5@localhost procedure pro_inbound_approve(IN u_inbound_id int)
BEGIN
    DECLARE a int;
    update inbound set status = '승인 수락' where inbound_id = u_inbound_id;


    -- INSERT INTO inventory (product_id, warehouse_id)
    -- SELECT product_id, warehouse_id
    -- FROM inbound
    -- WHERE inbound_id = u_inbound_id;
    SELECT inbound_quantity INTO a FROM inbound WHERE inbound_id = u_inbound_id;
    update inventory set quantity = quantity + a where product_id = (SELECT product_id FROM inbound WHERE inbound_id = u_inbound_id);





end;

