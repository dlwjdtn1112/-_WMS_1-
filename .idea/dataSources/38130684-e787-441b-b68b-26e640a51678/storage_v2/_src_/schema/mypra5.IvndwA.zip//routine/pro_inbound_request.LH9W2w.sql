create
    definer = mypra5@localhost procedure pro_inbound_request(IN u_product_id varchar(20), IN u_inbound_quantity int,
                                                             IN u_req_inbound_day varchar(20),
                                                             IN u_warehouse_id varchar(20))
BEGIN
    insert into inbound(product_id, inbound_quantity, req_inbound_day, warehouse_id)
    values (u_product_id,u_inbound_quantity,
            u_req_inbound_day,u_warehouse_id);

end;

