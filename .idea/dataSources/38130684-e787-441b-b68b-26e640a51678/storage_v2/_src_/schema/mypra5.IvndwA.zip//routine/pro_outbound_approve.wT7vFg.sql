create
    definer = mypra5@localhost procedure pro_outbound_approve(IN u_outbound_id int)
BEGIN
    DECLARE a int;
    update outbound set status = '승인 수락' where outbound_id = u_outbound_id;



    SELECT outbound_quantity INTO a FROM outbound WHERE outbound_id = u_outbound_id;
    update inventory set quantity = quantity - a where product_id = (SELECT product_id FROM outbound WHERE outbound_id = u_outbound_id);

end;

