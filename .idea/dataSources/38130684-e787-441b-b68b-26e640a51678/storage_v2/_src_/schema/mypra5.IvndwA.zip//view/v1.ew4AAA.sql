create definer = mypra5@localhost view v1 as
select `mypra5`.`productdata`.`product_code`   AS `product_code`,
       `mypra5`.`productdata`.`product_series` AS `product_series`,
       `mypra5`.`productdata`.`product_brith`  AS `product_brith`,
       `mypra5`.`productdata`.`current_state`  AS `current_state`
from `mypra5`.`productdata`;

