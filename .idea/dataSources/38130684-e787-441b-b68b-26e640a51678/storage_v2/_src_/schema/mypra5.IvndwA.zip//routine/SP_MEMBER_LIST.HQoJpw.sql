create
    definer = mypra5@localhost procedure SP_MEMBER_LIST(IN V_USERID varchar(50), IN V_PWD varchar(50),
                                                        IN V_EMAIL varchar(50), IN V_HP varchar(20), OUT RTN_CODE int)
BEGIN
    SET @strsql = CONCAT(
            ' SELECT' , '(m_userid, m_pwd, m_email, m_hp, m_registdate, m_poin)' , ' from TB_MEMBER' );

    prepare stmt from @strsql;
    execute stmt using @userid, @pwd, @email, @hp, @point;
    deallocate prepare stmt;
    commit;
end;

