create
    definer = mypra5@localhost procedure GetUserInfoByName(IN input_name varchar(100))
BEGIN
    SELECT * FROM usertbl WHERE name = input_name;
END;

