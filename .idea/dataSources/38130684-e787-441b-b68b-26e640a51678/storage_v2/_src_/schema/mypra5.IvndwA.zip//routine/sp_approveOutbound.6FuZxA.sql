create
    definer = mypra5@localhost procedure sp_approveOutbound(IN p_outbound_number varchar(30), IN p_prod_id varchar(10))
BEGIN
UPDATE outbound
SET status = 2
WHERE outbound_number = p_outbound_number AND prod_id = p_prod_id;
END;

